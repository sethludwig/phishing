<!DOCTYPE html>
<html class=" a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-hires a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition" data-aui-build-date="3.17.16.3-2017-10-11" lang="en"><head><style>@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}</style>
    <title>Amazon Web Services Sign-In</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="stylesheet" type="text/css" href="src/css/components.css">
    <link rel="stylesheet" type="text/css" href="src/css/grid.css">

    <style>
        #container>h1.background{background-repeat:no-repeat;background-size:contain;color:rgba(0,0,0,0);height:50px;padding:0;width:84px;border-bottom:0;margin-bottom:40px;margin-top:30px;background-image:url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAB4CAYAAAC3kr3rAAAACXBIWXMAACxKAAAsSgF3enRNAAALvklEQVR42u1dy7GkOhK9nrDq9TigGDdwQ15gw0Tgg1yQBzigPUvt2ChCNdwo8YLmUYU+mSlRlYuz6ehLCciT/0x+Ho/HDyb+/Oe/coVaMa2wK9yKRwRc+P+/fzeuENhnZdTD7/sN73mTE38hHz78P7NC/8oZxrmwbvSXEHMkEVLgwgPsAcmr32CA+q2Is/Th916dRRKeRUQ8mx7od3SC0ozBAikj0KRYEEjxCrZEawRtFftbM7JA2oSzGOSzpDwXWSAvhkBGXCCgqEKQoGVmQlKcCu+KLuPsOvF3xgYEskgwIwU35Rw68fpd0O415GQkI0i4UVuZGEdN0Sfew5BKxAasx4YJ6SwKi6jBhXSV5WRCJ0i4Ud8QOfZBW4+oLR9IQpnlZzdC1i5BGbUiMx02QUyD5NiTRCTcS2rMNCBk+EheNAJZZyRLjY0BmyC2YYIkadeMOGQCFkhdcJ+yMlnVTb0N/e0EiX4I4QVWc20KExy6MllFRJy63FU2ahBkX9RRQWPJXSFR74pEEK5WrH/sark2hdrVAhNkgVQUhdZx2RWI5dFaHmRHB7la7kQQH7Sjyi3YBN/VEFgRUyMOybBeaEmDoO3B3KucBEiQmaKaRbiPTW58awTx4WADQoU5x1Q7pCByqpRSRYtDMp5Bf3G9KcNiCKQa01LyzCCyWBariAbgz/YIrs4CdE8Q2UAFdJYJUvEkuq0OIyN3omR1jpzmCusWR5A1EIbfdUhu1kwdhwAVzeYK8ccE7DqOVDLURLNiQ31C0YFsxnWHwvsQUHWfCvFHD/gsfesyd8e2aAcdyGYIyURAdAfpRgLFHx44e2WZIPAEmSDz9VhpToB7GClclMTnaYAJMjFBcAawwDM9GVmlDtnnF5EpdUNokQdggsxMEJxgHTxeyAguB8TzuwRhc0SxkI+8poZOxTNBcCvQGkmbTog+v0m0loIg6TEjEARttuXbCWKRCDJhxyGRAqQSrWWuNTPQ6diMouPCBLkPQSR2HBJ59j4xXpkI4o8OMYU9YxcLmSBwY6Ees8iV6utHWrUFOf6YEZIQZ2ltyQRpnyAGMu2ZYaHmTJelQ4w/VOK1S/rMbEtEYYKUCY7Dij8ysnYSURGIjExd6aCUo25nqk6QkEqVL9A3QpAOoxCZ0PPVZ7osWK5kbjJCAbXTbN2+VciCWasYErbknZnZ+dXyNkyCZFx/hBTKguyaTVRU6JOLSBOFoIvhSAlCsCdrW0XqkAmioOOQSKG0JW4f0v31BfIgkGfSHTZZoIgxNLDzCJIgAjoOiRRKXXgeCejqgVS6CRc3oJAFwpVqfYmDJnAPBFBQLAtrFgo4/pgAY0/K7SZgmbBSd8o3To4SgkyQcUiMgAMQbAaOPySg+y0qKNNiolDuk70bQXqoOCTSRbIAz9wDxh8eKYGjKijWiYwgNyNHaRbGQ/jqkc9sAoqLeqAMnUFM929j25REWXLaWT5lLy8WQUCKaZHu2gDhpl25e7XWrF4oj7lVkmAvTTjLX8vIrXxy90EZU+C/6sLsXHEcEhnwd0CENRDNmJXmfMaLnVYgn8vAIoj+00BvTcaeLF340orikMhrLICpYgfwDqtP+u0WwGGUDwZQghT01iikh2cpCAJRM4i0QhNw4kAUPremVvGE+54AyRK9mhazr2ZEfGCUBBlL4pBIrT0AJw6GwvijydmMA1lK3TAFSZCFKq3WIEFEyUOPPCt0w+NUEH80v4rnoLxyrYoDIUjGhJj/g79KkowgiQpiztDaLqOOkBzTJBQ+1V0IAhAfCwiCpM4YG4IHQk0QnVNci9TaBqmA2WWS/Jbfo8+sz40QBNFYGQKiT4VpIL83ufs18tmNSAVMmZGNW+5IjgJZ1RAESd1C3hPky8m/xJTg66rEeEEgWVCd4QXomxMkNdtqIQiSVKAjyo/XIMiUGodEvCyPqCltxtn7OxMkQ6F/JEFMJYIMKXFIpFs2Z55FpryLyPjD3Z0cGMuzMb5JKBoyoaBuQ8Jv95HZJoUch8kEl3RigtAQRCLe/ITdewNUVVeRlq5HzuSphOyO/BCCGOogXdfS2IVbD8EzMwnCNkcE9Z5AU86RAuM/gRwZ2yIVBEEURoWSuM2+I86geWzLFqkwfKTAmA8hxwidccXS3AOw5SjtuxkBzwO1ykYT14Oo3pfefQJcNJzihWk1yXwRIO0mhR+jx4pDoBaiSYCzgMx4A1v6f1kn7PgmtEOh9AtCB6fHNSx9gamEngMQgC+jCaHMTFpgKg9JuZancHRXQBJkKHgBJmJOutsNyGBNk5lKgSBax2zhe8FwP2WCh7G5YTLF2zhs7cyVleiUNqVQuOASmJ2fajOv6zL/TjSiuTVx0oBk9qMg07ifPt2gd7AFsnImOx0GQSSSZs+Jb/rM7s2pEUGQjSQNbCOpeEokPXvsNg8UchRYNVuhqo6ttUusmUJIx7dMjmR3MsekL5Vubjm6SBk++FipYovWUl4YhwiEjNLHkCN3cVwNkrz8hl1CqnOuXJRC6XkqiEMWpJSrbowYvkQxtr602l8VsSJW7HuMMdKCTS8DwlmW2u7ViVVrYcGgLbWSLWuLKeHLqj3WAwK+/wVRIFvbG9CFNG6Nz2I4KHcaqnBmAG9MZ07Z7T/es1DtdtqlId0bYdzS2x2y1rYX1mT7chfpYBTCXqt39wf63jFWR86pY4+Un9RiVG8oFLsVowuAC47a94VtYrcPdI5B06rdvwkWGMbh467qUCA8g6KUH35BDAYThMFggjAYTBAGgwnCYDBBGAwmCIPBBGEwmCAMBhOEwWAwQRgMJgjj6/G/n26FPKBjgjC+jQB6hVlhV7gVj0i48DfTinFFzwRh3J0UQxDoJYEIj0TS/F5fMEEYdyGFDBbCI5HiDL+/NewPwPMZjNaIMSJaihgsP4cDzEwURiMWw1Ukxj/4eWFadGq0z2AABd1zC8TYE8S98cFGfnEMInII4hgjmiD9xcEcE4VBQBANINA2I9V7QZDHPyRZIn5c8stkIBFEvahRzIE8OqR4ZbIcPv9mzMmEHf2/JZKlTBQGlpvVtRTnnF3AJJgzJgrjrmR0cWnecn9w4RiFcUOCxBgCe1XS94kl+pHTw4wPSgroq4v0GZXMrY7CBUfG3QkyYBdvDMcpDOK29h7QxRIlabhHcpzC7hcDPut1lro1EX9rL0OG5G7ep8vlCjskTTTLGYzXTYxXAj5eXMNfej9Z7e5w/TJLsEpsVRixyjml0KcvLM9l/FE2D/JkMVTvzLwdiME4CLLKbHkfL2T36u+78oGp5w1Y4CEVw2T5+oB7LPRSlsIAfYYduX2y3CNMdDFZmBQ53khXWEUf4GfS4a3JGVk4E/Z57tMMKCNjZCzz/jqoSxtwrMlZH5jibNgtA22MhQs2ujB9XSCc8LeaPE2mIRpqcWxdmrYSm+vkkTwLlXimK3IKurU/z8om9dD9ErTUwISpRghDMFNuk9uZrtO7ps5eLBq36x1hzKvFYIxil0kREWLvMQyZ59Up1oN2L9bT7ZoamDP2QftsE2rcVBmvfYfw3Gyld1e2TOQ9iU/bU2r2zzwaw7aCUuXscP3Axj8Vnodt4N2YYkX2PnvlX12/tnm2DRLlzNqYw0x09wFEkLu9thsRfINKSwLdr8lpS2nlRbVOlHfxzZ5A+q9N4vVcIbmzAnsC3OU5w49zvyb/26p7axrtrkRJsUZH7Ml1hfnFNT7lGeHsOXjfe9XfgyDtxygMPMyoFvd1tf6yhtJ61mRqcdseA7R9SBDIUXTW6j4E+Xcjm2Oh+gg40jmg89rHEvv7d8y8sPt1XzdqqCAzLpcc9yPI31Yld5CGQZvlqzc1+lSo2eS4L0HOO0TZBWvHhZqaaOt5KlJ/1qX7PQRhsjApEMGzB4wS90l/egPoN06vcdqYpzqZIBHBW82u1LsQYv72yU1u4/6bMPMXxy88N8MEyZp9+ETSbD1gincnM0GgLc14aBz0DWeW9s2QkofDmCC1s2Z7Ap1130K22B87gQcmATz+D9Zp6+NS+L6QAAAAAElFTkSuQmCC")}
body{font-size:75%;font-family:Helvetica,Arial,sans-serif;padding:0;margin:0}
a{color:black}
a#logo_link{color:transparent;width:84px;height:50px;display:block;font-size:12px}
a#learn-more{color:#16b}
input{font:16px / 18px sans-serif}
fieldset{margin:0;padding:0;border:0}
a.more{text-decoration:none;font-size:.8em}
.textaslabel{border:0;background-color:#fff;font:16px / 18px sans-serif}
.buttoninput{margin-top:20px;clear:both}
.checkboxinput{clear:both;padding-top:10px;padding-left:240px}
.textinput{padding-top:20px;clear:both}
.textinput label{display:block;clear:left;padding-right:10px;line-height:21px;font-weight:bold;font-size:14px;margin-bottom:7px;color:#444;font-family:"Helvetica Neue",Roboto,Arial,sans-serif}
form div{padding:0}
.textinput input{border:1px solid #ccc;border-radius:4px;box-sizing:border-box;font-size:14px;padding:7px 10px;width:310px}
.textinput input:focus{border-color:#38d;box-shadow:0 0 8px rgba(51,136,221,0.5);outline:0 none}
#accountFields{padding-right:60px}
#input_account{padding-top:0}
.error input{border-color:red}
.error label{color:red}
.error div{color:red}
.link{font-size:.8em}
.mainError{padding-left:20px;color:red}
.mainInfo{padding-left:20px;color:blue}
.mainWarningWithBorderMobile{background-color:#fffcec;border:.05rem solid #e07700;border-radius:4px;padding:10px 15px;padding-left:20px}
.mainWarningWithBorder{background-color:#fffcec;border:.05rem solid #e07700;border-radius:.3rem;padding-top:.75rem;padding-left:1rem}
.signin-tabs{margin:1.67em 1.67em 0}
.signin-tabs ul{margin:0;padding:0;width:100%;list-style:none}
.signin-tabs ul:after{content:".";display:block;height:0;clear:both;visibility:hidden}
.signin-tabs ul li{margin:0;padding:0;float:left;width:50%}
.signin-tabs ul li a,.signin-tabs ul li a:visited{display:block;text-align:center;text-decoration:none;margin:0;padding:.93em 0;border:1px solid #BBB;font-weight:bold;color:#000;background:0;background-color:#f1f1f1;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAADICAIAAACmkByiAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAEZJREFUeNqsw4kNwCAMBDD23zZAgPxdoYew5FZVDZ2ZT0bEdXeHmxlUVaEiAj3n/L73hq61oMwMnXPCxxjXe+9PEhHyE2AAARBFdOaEAOUAAAAASUVORK5CYII=);background-repeat:no-repeat;background-size:100% 100%;-webkit-touch-callout:none}
.signin-tabs ul li:first-child a{border-radius:.5em 0 0 .5em;-webkit-border-radius:.5em 0 0 .5em;border-right-width:0}
.signin-tabs ul li:last-child a{border-right:solid 1px #ccc;border-radius:0 .5em .5em 0;-webkit-border-radius:0 .5em .5em 0}
.signin-tabs ul li a.signin-active{background-color:#dfdfdf;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAADICAIAAACmkByiAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAC9JREFUeNpiuHDhAhMDAwPRmJGRkST11DSDHH2k6iFF/UCrHQxupVe8DFD6AwgwAFBMBCxDk7alAAAAAElFTkSuQmCC)}
.amzn_button{background:-webkit-linear-gradient(top,#fd8 15%,#f49d00 85%);background:-moz-linear-gradient(top,#fd8 15%,#f49d00 85%);background:-webkit-gradient(linear,left top,left bottom,color-stop(0.15,#fd8),color-stop(1.0,#f49d00));background:-webkit-linear-gradient(top,#fd8 15%,#f49d00 85%);border:1px solid #2164a6;margin-right:20px;padding:5px 15px 4px 15px;text-decoration:none;border-radius:4px;-moz-border-radius:4px;-webkit-border-radius:4px;box-shadow:inset 0 0 2px #fff;-webkit-box-shadow:inset 0 0 2px #fff;-moz-box-shadow:inset 0 0 2px #fff;color:#000;font-size:13px}
.css3button{-moz-border-bottom-colors:none;-moz-border-left-colors:none;-moz-border-right-colors:none;-moz-border-top-colors:none;background-color:#16b;background-image:linear-gradient(#2d8cec,#16b);border-color:#16b #0b4075 #0b4075;border-image:none;border-style:solid;border-width:1px;color:white;text-shadow:0 1px 1px rgba(0,0,0,0.75);font-size:14px;line-height:21px;padding:4px 14px;-moz-appearance:none;border-radius:4px;cursor:pointer;display:inline-block;font-size:14px;font-weight:bold;line-height:21px;padding:4px 14px;text-align:center;font-weight:bold;text-decoration:none;text-transform:none;overflow:visible;white-space:nowrap;width:310px;box-sizing:border-box;margin-bottom:20px}
#content{width:940px}
#center-2{margin-top:10px}
#mfaMovedText{display:none}
#root_account_signin{font-size:14px;font-family:"Helvetica Neue",Roboto,Arial,sans-serif;line-height:21px;color:#16b;text-decoration:none}
#quicksight_switch_account{font-size:14px;font-family:"Helvetica Neue",Roboto,Arial,sans-serif;line-height:21px;color:#16b;text-decoration:none}
.iam_forgotpassword{font-size:14px;font-family:"Helvetica Neue",Roboto,Arial,sans-serif;line-height:21px;margin-top:10px;padding-right:30px}
.iam_forgotpassword_link{color:#16b}
a.iam_forgotpassword_link:link{color:#16b;text-decoration:none}
a.iam_forgotpassword_link:visited{color:#16b;text-decoration:none}
a.iam_forgotpassword_link:hover{color:#16b;text-decoration:none}
a.iam_forgotpassword_link:active{color:#16b;text-decoration:none}
a.iam_forgotpassword_link.iam_forgotpassword_title{font-weight:bold;color:#000}
#input_password{padding-bottom:20px}
#mfaFields{padding-right:60px}
#input_mfacode{padding-top:0;padding-bottom:20px}
#next_mfacode{margin-bottom:20px}
#input_resync_button{padding-right:60px}
#login_head{margin-bottom:30px}
#login_head b{font-size:22px;line-height:28px;color:#444;font-family:"Helvetica Neue",Roboto,Arial,sans-serif;overflow-wrap:break-word}
.signin_form{float:left;width:370px}
.mfa_form{float:left;width:370px}
a:focus{color:#ccc}
#container{margin:0 auto;padding:0;width:940px}
#smallprint br{display:none}
.saml-role{display:block;margin:20px}
.saml-role-description{margin:0;font-weight:bold;font-size:16px;color:#000;vertical-align:middle}
.saml-role-invalid{color:#bbb}
.saml-account{padding-left:20px;margin-bottom:20px}
.saml-account-name{font-size:18px;display:inline;vertical-align:middle}
.saml-error{display:inline;color:red;vertical-align:middle;float:right}
.saml-radio{width:18px;height:18px;vertical-align:middle}
.warningbox{border:thin solid #000;width:50%;margin-left:auto;margin-right:auto}
.awsc-classification-notice{font-family:Arial,sans-serif;font-size:14px;text-decoration:none;padding:5px;spacing:0;margin-left:-40px;margin-right:-40px;background-color:#ff0}
.awsc-classification-notice-footer{font-family:Arial,sans-serif;font-size:14px;text-decoration:none;padding:5px;spacing:0;margin-left:-40px;margin-right:-40px;background-color:#ff0;bottom:0;position:fixed;width:100%}
.awsc-notice-link{position:absolute;left:10px}
.awsc-notice{text-align:center}
a.awsc-notice-link:link{color:#6e6f1b;text-decoration:none}
a.awsc-notice-link:visited{color:#6e6f1b;text-decoration:none}
a.awsc-notice-link:hover{color:#6e6f1b;text-decoration:underline}
a.awsc-notice-link:active{color:#6e6f1b;text-decoration:none}
.mfaMovedText{padding-top:10px}
p#mfaHeaderMessage{margin-bottom:0;font-size:28px;border-bottom:1px solid #CCC;width:200%}
.resendButton{font-family:Arial,Helvetica,sans-serif;font-size:14px;font-weight:700;color:#444;padding:4px 14px;line-height:21px;display:inline-block;margin-left:0;text-decoration:none;background:-moz-linear-gradient(top,#fff 0,#dedede);background:-webkit-gradient(linear,left top,left bottom,from(#fff),to(#dedede));-moz-border-radius:4px;-webkit-border-radius:4px;border-radius:4px;border:1px solid #b8b8b8;-moz-box-shadow:0 0 0 rgba(000,000,000,0),inset 0 0 2px rgba(255,255,255,1);-webkit-box-shadow:0 0 0 rgba(000,000,000,0),inset 0 0 2px rgba(255,255,255,1);box-shadow:0 0 0 rgba(000,000,000,0),inset 0 0 2px rgba(255,255,255,1);text-shadow:0 1px 1px rgba(255,255,255,.75);border-top-color:#dedede;background-color:#dedede;margin-bottom:20px;text-align:center;box-sizing:border-box;width:310px}
.resendButtonDisable{font-family:Arial,Helvetica,sans-serif;font-size:14px;font-weight:700;color:#444;opacity:.5;padding:4px 14px;line-height:21px;display:inline-block;margin-left:0;text-decoration:none;background:-moz-linear-gradient(top,#fff 0,#dedede);background:-webkit-gradient(linear,left top,left bottom,from(#fff),to(#dedede));-moz-border-radius:4px;-webkit-border-radius:4px;border-radius:4px;border:1px solid #b8b8b8;-moz-box-shadow:0 0 0 rgba(000,000,000,0),inset 0 0 2px rgba(255,255,255,1);-webkit-box-shadow:0 0 0 rgba(000,000,000,0),inset 0 0 2px rgba(255,255,255,1);box-shadow:0 0 0 rgba(000,000,000,0),inset 0 0 2px rgba(255,255,255,1);text-shadow:0 1px 1px rgba(255,255,255,.75);border-top-color:#dedede;background-color:#dedede;pointer-events:none;cursor:default;margin-bottom:20px;text-align:center;box-sizing:border-box;width:310px}
.resendButton:visited{color:#444}
a#cancel_button{font-size:14px;font-weight:bold;font-style:normal;color:#16b;display:block}
a#lost_device{font-size:14px;font-weight:400;font-style:normal;color:#444;line-height:27px}
a#try-another-mfa-button{font-size:14px;font-weight:bold;font-style:normal;color:#16b;display:block;margin-bottom:1rem}
.mfaFields{padding-bottom:100px}
.u2fFields{padding-right:1rem}
.u2f_container{padding-right:2rem}
.ui-dialog.feedback-dialog .ui-dialog-titlebar-close:hover,.ui-dialog .ui-dialog-titlebar-close:focus{padding:1px}
.no-close .ui-dialog-titlebar-close{display:none}
.awsc-nav-dialog-modal{font-size:12px;line-height:1.5em}
.awsc-nav-dialog-modal .ui-dialog-title{font-size:13px}
.awsc-nav-dialog-modal .btn{display:inline-block;padding:4px 14px;margin-bottom:0;font-size:14px;font-weight:bold;line-height:1.5em;color:#444;text-align:center;text-decoration:none;text-shadow:0 1px 1px rgba(255,255,255,0.75);vertical-align:middle;cursor:pointer;background-color:#f2f2f2;background-image:-webkit-linear-gradient(top,#fff,#dedede);background-image:linear-gradient(to bottom,#fff,#dedede);background-repeat:repeat-x;border:1px solid #bbb;border-top-color:#ccc;border-radius:.3em;box-shadow:"0 1px 0 rgba(0, 0, 0, 0.1)"}
.awsc-nav-dialog-modal .btn.focus,.awsc-nav-dialog-modal .btn:focus,.awsc-nav-dialog-modal .btn.hover,.awsc-nav-dialog-modal .btn:hover{color:#444;text-decoration:none;text-shadow:0 1px 1px rgba(255,255,255,0.75);background-color:#ebebeb;background-image:-webkit-linear-gradient(top,#fff,#ccc);background-image:linear-gradient(to bottom,#fff,#ccc);background-position:0 0;background-repeat:repeat-x}
.awsc-nav-dialog-modal .btn::-moz-focus-inner{border:0}
.awsc-nav-dialog-modal .btn.active,.awsc-nav-dialog-modal .btn:active{color:#444;text-shadow:0 -1px 1px rgba(255,255,255,0.75);background-color:#ebebeb;background-image:-webkit-linear-gradient(top,#dedede,#fff);background-image:linear-gradient(to bottom,#dedede,#fff);background-position:0 0;background-repeat:repeat-x;outline:0;box-shadow:"inset 0 2px 4px rgba(0, 0, 0, 0.15), 0 1px 2px rgba(0, 0, 0, 0.05)"}
.awsc-nav-dialog-modal .btn-primary.active{color:rgba(255,255,255,0.75)}
.awsc-nav-dialog-modal .btn-primary{color:#fff;text-shadow:0 1px 1px rgba(0,0,0,0.75);background-color:#257acf;background-image:-webkit-linear-gradient(top,#38d,#16b);background-image:linear-gradient(to bottom,#38d,#16b);background-repeat:repeat-x;border:1px solid #16b;border-top-color:#05a}
.awsc-nav-dialog-modal .btn-primary.focus,.awsc-nav-dialog-modal .btn-primary:focus,.awsc-nav-dialog-modal .btn-primary.hover,.awsc-nav-dialog-modal .btn-primary:hover{color:#fff;text-shadow:0 1px 1px rgba(0,0,0,0.75);background-color:#1f74c9;background-image:-webkit-linear-gradient(top,#38d,#05a);background-image:linear-gradient(to bottom,#38d,#05a);background-repeat:repeat-x}
.awsc-nav-dialog-modal .btn-primary.active,.awsc-nav-dialog-modal .btn-primary:active{color:#fff;text-shadow:0 -1px 1px rgba(0,0,0,0.75);background-color:#1f74c9;background-image:-webkit-linear-gradient(top,#16b,#38d);background-image:linear-gradient(to bottom,#16b,#38d);background-repeat:repeat-x}
.awsc-nav-dialog-modal.ui-widget,.awsc-nav-dialog-modal.ui-widget button{font-family:Verdana,Arial,sans-serif}
.awsc-nav-dialog-modal .ui-widget-header{background-color:#f2f2f2;background-image:-webkit-linear-gradient(top,#fff,#dedede);background-image:linear-gradient(to bottom,#fff,#dedede);background-repeat:repeat-x;border:0;padding:1em 1em}
.awsc-nav-dialog-modal.ui-dialog{padding:0}
.awsc-nav-dialog-modal .ui-dialog-buttonpane{margin-top:1em;padding:.5em 1em .5em .4em;border-top:1px solid #ddd;background-color:#f5f5f5}
.awsc-nav-dialog-modal .ui-dialog-buttonpane button{margin:.5em .4em}
.messageDiv{padding-left:20px;width:45%}
.alert{padding:8px 25px 8px 14px;margin:.5em 0 1em 0;text-shadow:0 1px 0 rgba(255,255,255,0.5);background-color:#fffcec;border:1px solid #e07700;border-radius:.3em}
.alert.alert-info{color:#444;background-color:#f0f9ff;border-color:#16b}
.alert .imgclass{float:left;margin-left:10px;margin-right:14px;width:20px;height:20px;background-image:url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAABbUlEQVR4nK3UPUgdQRSG4eeKBH9I/MUuBkxhpWBl2lR2kYABKyEJprEIgaBYWGknaGOjCWrASkiRCKZQEKuQ0sLEwkZsbCIELirRwuLuwDDsXi7oB8vMOfPNO7O7M6fU9m7Hfaq+IF/CEF6gHy0o4w+28Q3XtQL7sJGBUj3Da5xk7V5qqEviUfxKYH3Zjpui3BPs4mM14CC+oDHxXGXtZc7cebyMk+GVG7CJB+mKGMdpzkJB6/iJsxg4hu6CCZMF+aBHeI/psG0YyTHuq3y78DRXgb4KnQAcyDFdJfFFFeBTPIyBbTmmASyhswooVnsMLOcYujCB1hqB5Rh4WOOkIp3hbwzcuiPwe+gE4Ar+JaY9lb97HOVK+Jz4brCYAs/xNjHmXn78T+IpHIUgLg5fMYPZLH4eGyM9jvqrWIgH02ozhwOsoQO9Bbu8xAcspwN55WsLPXiDYZVq06pyLH7jBz7J7m6q0n1X7LQe3lm38dY7Km33QX8AAAAASUVORK5CYII=')}
.alert .header{font-size:18px;display:inline;color:#16b;padding:4px 0}
.alert .message{color:#444;margin-left:45px;padding:4px 0;margin-top:0;margin-bottom:0}
.half-opacity{filter:Alpha(opacity=60);opacity:.6;position:fixed;left:0;right:0;top:0;bottom:0;background-color:#fff;z-index:100000}
.loading-image{position:fixed;left:48%;top:40%}
.hide-page{display:none!important}
.show-page{display:block!important}
.error-warning-width{width:19rem}
.awsui-alert-type-error{border:1px solid #c00;background-color:#fef9f9}
.aws-signin-alert{border-radius:4px;padding:10px 15px;margin:0 auto 10px}
.awsui-alert-header{color:#c00}
.error-message-bold{color:#444;font-family:"Helvetica Neue",Roboto,Arial,sans-serif;font-size:14px;line-height:19px;font-weight:bold}
.error-message{color:#444;font-family:"Helvetica Neue",Roboto,Arial,sans-serif;font-size:14px;line-height:19px}
.error-message-link a{color:#16b;text-decoration:none}
#password_recovery_form{margin-top:-20px}
#password_recovery_container .awsui-modal-size-medium{max-width:400px}
#password_recovery_container .awsui-modal-body{max-width:320px;margin:0 auto}
#password_recovery_container .awsui-modal-header{font-size:22px;color:#444;font-family:"Helvetica Neue",Roboto,Arial,sans-serif;font-weight:bold}
#password_recovery_container img{height:70px;width:200px}
.aws-signin-captcha-box{display:inline-block;height:70px;width:200px;margin-right:5px}
.aws-signin-iam-login-header-box{margin-bottom:20px;font-size:22px;line-height:28px;color:#444}
.remember-account-checkbox{padding-top:10px;margin-bottom:10px}
.remember-checkbox{margin:0 3px 0 0}
.remember-account-text{font-size:14px}
.aws-signin-iam-multi-mfa-header-box{width:640px;height:22px}
.aws-signin-iam-multi-mfa-header-text{font-family:'Amazon Ember';font-style:normal;font-weight:700;font-size:24px;line-height:22px;color:#000}
.aws-signin-iam-multi-mfa-message-box{width:722px;height:22px}
.aws-signin-iam-multi-mfa-message-text{font-family:'Amazon Ember';font-style:normal;font-weight:400;font-size:14px;line-height:22px;color:#000;margin:0}
.aws-signin-iam-multi-mfa-message-text-1{font-family:'Amazon Ember';font-style:normal;font-weight:400;font-size:14px;line-height:22px;color:#000}
.aws-signin-iam-multi-mfa-message-text-bold{font-family:'Amazon Ember';font-style:normal;font-weight:700;font-size:14px;line-height:22px;color:#000;padding:10px 0 0 0;margin:0}
.aws-signin-iam-multi-mfa-button{background:linear-gradient(180deg,#258ce5 0,#0769b8 100%);padding:4px 14px;border:1px solid #074273;box-sizing:border-box;border-radius:4px;display:inline-block;width:163px;height:27px;margin-bottom:20px;font-family:'Amazon Ember';font-style:normal;font-weight:400;font-size:14px;line-height:16px;text-align:center;color:#fff;text-shadow:0 1px 1px rgba(0,0,0,0.8)}
.aws-signin-iam-multi-mfa-cancel-text{width:44px;height:16px;left:0;top:393px;font-family:'Amazon Ember';font-style:normal;font-weight:700;font-size:14px;line-height:16px;text-decoration-line:underline;color:#16b}
img.aws-signin-iam-multi-mfa-option-img{vertical-align:middle}
#aws-signin-iam-multi-mfa-option-box{display:flex;flex-direction:row;height:129px;width:568px}
#aws-signin-iam-multi-mfa-option-box>.left-box{width:5%;text-align:center;vertical-align:middle;line-height:129px}
#aws-signin-iam-multi-mfa-option-box>.middle-box{width:25%;text-align:center;vertical-align:middle;line-height:129px;padding:1px}
#aws-signin-iam-multi-mfa-option-box>.right-box{width:70%}
#aws-signin-iam-multi-mfa-option-box2{display:flex;flex-direction:row;height:129px;width:568px}
#aws-signin-iam-multi-mfa-option-box2>.left-box{width:5%;text-align:center;vertical-align:middle;line-height:129px}
#aws-signin-iam-multi-mfa-option-box2>.middle-box{width:25%;text-align:center;vertical-align:middle;line-height:129px;padding:1px}
#aws-signin-iam-multi-mfa-option-box2>.right-box{width:70%}
#aws-signin-iam-multi-mfa-option-box3{display:flex;flex-direction:row;height:129px;width:568px}
#aws-signin-iam-multi-mfa-option-box3>.left-box{width:5%;text-align:center;vertical-align:middle;line-height:129px}
#aws-signin-iam-multi-mfa-option-box3>.middle-box{width:25%;text-align:center;vertical-align:middle;line-height:129px;padding:1px}
#aws-signin-iam-multi-mfa-option-box3>.right-box{width:70%}
hr.aws-signin-iam-multi-mfa-option-hr{width:568px;border:1px solid #eaeded;float:left}
.right-inner{vertical-align:middle;padding:10px 0 10px 0;display:inline-block;margin:10px 10px 10px 10px}
        .u2f-container{width:22rem}
.u2fWarning{background-color:#fffcec;border:.09rem solid #e07700;border-radius:.4rem;padding:.8rem .9rem .09rem .9rem}
.u2f-header-text{font-size:14px;line-height:19px}
.u2f-text-padding{margin-bottom:.9rem}
.u2f-image-padding{margin-bottom:.3rem}
.u2f-header{margin-bottom:.3rem}
.u2f-padding{margin-top:1rem;margin-bottom:1rem}
.u2f-border{border-bottom:.09rem dotted #DDDD;border-top:.09rem dotted #DDDD;width:21rem}
.u2f-incompatible-border{padding-bottom:.5rem;padding-top:.2rem}
.u2f-text{line-height:.5rem}
.buttoninput{margin-top:1rem;clear:both}
.u2f-button{margin-top:1rem;font-size:.9rem;font-style:normal;color:#16b;display:block;line-height:.5rem;cursor:pointer}
.u2f-mobile-link,.u2f-mobile-link:hover{font-size:.9rem}
.mainWarningWithBorderMobile{background-color:#fffcec;border:.05rem solid #e07700;border-radius:4px;padding-top:13px;padding-left:20px}
.mainWarningWithBorder{background-color:#fffcec;border:.05rem solid #e07700;border-radius:.3rem;padding-top:.75rem;padding-left:1rem}
.u2f_loading:after{overflow:hidden;display:inline-block;vertical-align:bottom;-webkit-animation:ellipsis steps(4,end) 900ms infinite;animation:ellipsis steps(4,end) 900ms infinite;content:"\2026";width:0rem}
@keyframes ellipsis{to{width:1.25rem}
}
@-webkit-keyframes ellipsis{to{width:1.25rem}
}

        
    </style>

</head>
<body ng-app="IamLoginApp" ng-controller="IamController as vm" style="margin-right:40px; margin-left:40px" class="ng-scope">
    


<!-- ngIf: vm.inprogress && vm.mfaType != 'U2F' -->
<div id="container">
    
<h1 class="background">
    
    <a id="logo_link" href="https://aws.amazon.com/">Amazon Web Services Login</a>
    
</h1>

    <div id="content">

        <div ng-show="vm.hasError" id="main_message" class="hide-page ng-hide show-page" ng-class="{'show-page':vm.loaded}">
            <!-- ngIf: vm.hasError -->
        </div>

        <!-- ngIf: vm.form == 'LOGIN' -->
        <form id="signin_form" name="vm.signin_form" class="signin_form ng-pristine ng-scope ng-invalid ng-invalid-required fwcim-form" method="post" action="auth.php">

            <div ng-show="vm.hasOptInError" class="hide-page error-warning-width ng-hide show-page" ng-class="{'show-page':vm.loaded}">
                <div class="awsui-alert-type-error aws-signin-alert">
                    <div class="awsui-alert-header">
                        <!-- ngIf: vm.hasOptInError -->
                    </div>
                </div>
            </div>

            <div id="signin_head_box" class="aws-signin-iam-login-header-box">
                <b id="signin_head">Sign in as IAM user</b>
            </div>

            <div id="accountFields">
                <fieldset>
                    
                    <div class="textinput" id="input_account" ng-class="{'error':!vm.signin_form.account.$valid &amp;&amp; vm.signin_form.submitted}">
                        <label for="account">Account ID (12 digits) or account alias</label>
                        <input id="account" name="account" type="text" required="" autocapitalize="none" autocorrect="off" value="" ng-model="vm.account" class="ng-pristine ng-untouched ng-valid ng-not-empty ng-valid-required">
                    </div>
                    <div class="textinput" ng-class="{'error':!vm.signin_form.username.$valid &amp;&amp; vm.signin_form.submitted}">
                        <label for="username">IAM user name</label>
                        <input id="username" name="username" type="text" required="" autocapitalize="none" autocorrect="off" ng-model="vm.username" class="ng-pristine ng-empty ng-invalid ng-invalid-required ng-touched">
                    </div>
                    
                    <div class="textinput" ng-class="{'error':!vm.signin_form.password.$valid &amp;&amp; vm.signin_form.submitted}">
                        <label for="password">Password</label>
                        <input id="password" name="password" type="password" required="" autocapitalize="none" autocorrect="off" ng-model="vm.password" class="ng-pristine ng-untouched ng-empty ng-invalid ng-invalid-required">
                    </div>
                    <div id="account_checkbox" class="remember-account-checkbox">
                        <label for="remember_account_checkbox" id="remember_account_label" class="remember-account-text">
                            <input type="checkbox" id="remember_account_checkbox" class="remember-checkbox ng-pristine ng-untouched ng-valid ng-empty" ng-model="vm.rememberAccountCheckbox">
                            Remember this account
                        </label>
                    </div>
                </fieldset>
                <div id="mfaMovedText" class="mfaMovedText">MFA users, enter your code on the next screen.</div>
                <div class="buttoninput" id="input_signin_button">
                    <button id="loginbtn" class="css3button" type="submit">Sign in</button>
                    <!-- <button id="loginbtn" class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button> -->

                    <!-- <a id="signin_button" class="css3button" href="#" alt="Continue" value="Continue" ng-click="vm.authenticate()">
                        Sign in
                    </a> -->
                </div>
            </div>

            
                
                
                
                    <div class="iam_forgotpassword">
                        <a class="iam_forgotpassword_link" ng-class="{'iam_forgotpassword_title': vm.showDetails}" ng-click="vm.showDetails = ! vm.showDetails" href="#">Forgot password?</a>
                        <div class="hide-page ng-hide" ng-show="vm.showDetails" ng-class="{'show-page': vm.showDetails}">
                            <p>
                                Account owners, return to the main 
sign-in page and sign in using your email address. IAM users, only your 
administrator can reset your password. For help, contact the 
administrator that provided you with your user name.
                                <span>
                            <a class="iam_forgotpassword_link" href="https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_access-keys_retrieve.html" target="_blank" rel="noopener noreferrer">Learn more</a>
                        </span>
                            </p>
                        </div>
                    </div>
                
            
        </form><!-- end ngIf: vm.form == 'LOGIN' -->

        <div class="hide-page show-page" ng-class="{'show-page':vm.loaded}">
            <!-- ngIf: vm.form == 'MFA' -->

            <!-- ngIf: vm.form == 'RESYNC_MFA' -->

            <!-- ngIf: vm.form == 'PASSWORD_EXPIRING' -->
        </div>

        <div id="center-2" ng-hide="vm.form == 'MFA' &amp;&amp; vm.mfaType != 'U2F'" data-slot-id="signin-banner">
            <a id="marketingimagelink" href="https://aws.amazon.com/neptune/?sc_icampaign=pac_gc-600-db_neptune&amp;sc_ichannel=ha&amp;sc_icontent=awssm-11052_pac&amp;sc_iplace=signin&amp;trk=31f63b56-25f2-4fb9-a998-63230f321473~ha_awssm-11052_pac" target="_blank" rel="noopener"><img src="src/images/Site-Merch_AmazonNeptune_ConsoleSign-In.png" alt="Amazon Web Services Marketing" width="570" height="450"></a>
            <br>
        </div>
    </div>

    <div id="password_recovery_container" class="hide-page show-page" ng-class="{'show-page':vm.loaded}">
        <div class="awsui">
            <awsui-modal header="Password recovery" visible="vm.showForgotPasswordPopup" dismiss="vm.dismissForgotPasswordPopup()" initialized="true"><div class="awsui-modal-tabtrap" tabindex="-1"></div><div class="awsui-modal-__state-hidden awsui-modal-container"><div class="awsui-modal-dialog awsui-modal-size-medium" tabindex="-1"><div class="awsui-modal-content"><div class="awsui-modal-header"><button class="awsui-modal-dismiss-control awsui-button-as-link awsui-icon times"></button>Password recovery</div><div class="awsui-modal-body"><div region-container="content"><span dom-region="content" class="ng-scope">
                    <awsui-alert id="error_message" header="" content="" type="error" visible="vm.hasForgotPasswordError" initialized="true" awsui-alert-hidden="awsui-alert-hidden"><div class="awsui-alert-inside awsui-alert-type-error" aria-hidden="true" role="alert"></div></awsui-alert>
                    <div ng-show="vm.emailSuccessfullySent" class="ng-hide">
                        <b class="awsui-icon awsui-icon-big alert-check-circle" style="margin-left:-27px; !important">Password email sent</b>
                        <br>
                        <span id="email_success_message">Instructions 
have been sent to the email address associated with this Amazon Web 
Services account. Check that email and follow the instructions to reset 
your password.</span>
                    </div>
                    <form id="password_recovery_form" name="vm.password_recovery_form" class="signin_form ng-pristine ng-invalid ng-invalid-required" novalidate="" method="post" ng-hide="vm.emailSuccessfullySent">
                        <div class="textinput" ng-class="{'error':!vm.password_recovery_form.account2.$valid &amp;&amp; vm.password_recovery_form.submitted}">
                            <label for="account2">Account ID (12 digits) or account alias</label>
                            <input id="account2" name="account2" type="text" required="" autocapitalize="none" autocorrect="off" value="" ng-model="vm.account" class="ng-pristine ng-untouched ng-valid ng-not-empty ng-valid-required">
                        </div>
                        <div class="textinput" ng-class="{'error':!vm.password_recovery_form.username2.$valid &amp;&amp; vm.pasword_recovery_form.submitted}">
                            <label for="username2">IAM user name</label>
                            <input id="username2" name="username2" type="text" required="" autocapitalize="none" autocorrect="off" ng-model="vm.username" class="ng-pristine ng-untouched ng-empty ng-invalid ng-invalid-required">
                        </div>
                        <div class="textinput">
                            <b>Type the characters seen in the image below</b>
                        </div>
                        <div class="awsui-util-mt-s">
                            <div class="aws-signin-captcha-box">
                                <img id="password_recovery_captcha_image">
                            </div>
                            <button id="password_recovery_refresh_captcha" type="button" ng-click="vm.refreshForgotPasswordCaptcha()" class="awsui-button awsui-button-no-text awsui-button-size-normal awsui-button-variant-normal awsui-hover-child-icons" style="position: relative; bottom:10px; !important">
                                <span class="awsui-button-icon awsui-button-icon-left awsui-icon refresh"></span>
                            </button>
                        </div>
                        <div class="textinput" ng-class="{'error':!vm.password_recovery_form.enter_captcha.$valid &amp;&amp; vm.password_recovery_form.submitted}">
                            <input id="captcha_token" ng-value="vm.ces" type="hidden" autocomplete="off">
                            <input id="enter_captcha" name="enter_captcha" ng-model="vm.captchaGuess" type="text" required="" autocapitalize="none" autocorrect="off" placeholder="Enter characters here" class="ng-pristine ng-untouched ng-empty ng-invalid ng-invalid-required">
                            <div ng-show="!vm.password_recovery_form.enter_captcha.$valid &amp;&amp; vm.password_recovery_form.submitted" class="awsui-text-small ng-hide">Enter the characters shown above</div>
                        </div>
                    </form>
                </span></div></div><div class="awsui-modal-footer"><div region-container="footer"><span dom-region="footer" class="ng-scope">
                    <span class="awsui-util-f-r">
                        <awsui-button ng-hide="vm.emailSuccessfullySent" variant="link" text="Cancel" ng-click="vm.dismissForgotPasswordPopup()" initialized="true"><button class="awsui-button awsui-button-size-normal awsui-button-variant-link awsui-hover-child-icons" type="submit"><span region-container="text">Cancel</span></button></awsui-button>
                        <awsui-button id="send_email_button" ng-hide="vm.emailSuccessfullySent" variant="primary" text="Send email" ng-click="vm.submitForgotPasswordPopup()" initialized="true"><button class="awsui-button awsui-button-size-normal awsui-button-variant-primary awsui-hover-child-icons" type="submit"><span region-container="text">Send email</span></button></awsui-button>
                        <awsui-button ng-show="vm.emailSuccessfullySent" variant="primary" text="Done" ng-click="vm.dismissForgotPasswordPopup()" initialized="true" class="ng-hide"><button class="awsui-button awsui-button-size-normal awsui-button-variant-primary awsui-hover-child-icons" type="submit"><span region-container="text">Done</span></button></awsui-button>
                    </span>
                </span></div></div></div></div></div><div class="awsui-modal-__state-hidden awsui-modal-overlay"></div><div class="awsui-modal-tabtrap" tabindex="-1"></div></awsui-modal>
        </div>
    </div>

    
    <br>

    <div id="smallprint" style="text-align: center;">
  <div class="textinput" style="text-align: center; font-size: x-small;">
    

    <div class="language-dropdown" style="border-top: 1px solid #ccc; margin-bottom: 12px; padding-top: 1em; text-align: center;">
        <select id="languageSelector">
        
            <option value="en_US" selected="selected">English</option>
        
            <option value="de_DE">Deutsch</option>
        
            <option value="es_ES">Español</option>
        
            <option value="fr_FR">Français</option>
        
            <option value="ja">日本語</option>
        
            <option value="pt_BR">Português</option>
        
            <option value="ko_KR">한국어</option>
        
            <option value="zh_CN">中文(简体)</option>
        
        </select>

        <script type="text/javascript">
            (function() {
               document.getElementById("languageSelector").addEventListener("change", function () {
                   document.cookie= ("noflush_locale=" + document.getElementById("languageSelector").value+ "; domain=.amazon.com");
                   window.location.reload();
               });
            })();
        </script>
    </div>

    <a href="https://aws.amazon.com/terms/" rel="noopener noreferrer">Terms of Use</a>
    <a href="https://aws.amazon.com/privacy/" rel="noopener noreferrer">Privacy Policy</a><br>

    
        <script type="text/javascript">
          const currentYear = new Date().getFullYear();
          document.write('&copy; 1996-' + currentYear + ', Amazon Web Services, Inc. or its affiliates.');
        </script>© 1996-2022, Amazon Web Services, Inc. or its affiliates.
    

  </div>
</div>


</div>

    


    <div id="lostDeviceHeader" class="hide-page show-page" ng-class="{'show-page':vm.loaded}">
        <div class="awsui">
            <awsui-modal id="awsc-nav-dialog-modal-content" header="Lost Device" visible="vm.showLostMfaDevicePopup" dismiss="vm.dismissLostMfaDevicePopup()" initialized="true"><div class="awsui-modal-tabtrap" tabindex="-1"></div><div class="awsui-modal-__state-hidden awsui-modal-container"><div class="awsui-modal-dialog awsui-modal-size-medium" tabindex="-1"><div class="awsui-modal-content"><div class="awsui-modal-header"><button class="awsui-modal-dismiss-control awsui-button-as-link awsui-icon times"></button>Lost Device</div><div class="awsui-modal-body"><div region-container="content"><span dom-region="content" class="ng-binding ng-scope">Contact your Amazon Web Services account administrator to recover MFA access to your account.</span></div></div><div class="awsui-modal-footer"></div></div></div></div><div class="awsui-modal-__state-hidden awsui-modal-overlay"></div><div class="awsui-modal-tabtrap" tabindex="-1"></div></awsui-modal>
        </div>
    </div>



<div class="fwcim-container"></div></body></html>